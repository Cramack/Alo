import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;

/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */
public class Board {

    private final int n;
    private int[][] tiles;

    private int hamming;
    private int manhattan;

    private int blankRow;
    private int blankCol;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tParams) {
        n = tParams.length;
        tiles = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tiles[i][j] = tParams[i][j];
            }
        }

        hamming = 0;
        manhattan = 0;
        blankRow = -1;
        blankCol = -1;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {

                if (tiles[i][j] == 0) {
                    blankRow = i;
                    blankCol = j;
                    continue;
                }

                int index = i * n + j + 1;
                int val = tiles[i][j];
                if (val != index) {
                    hamming++;

                    int tmpI = (val - 1) / n;
                    int tmpJ = val - tmpI * n == 0 ? n - 1 : val - tmpI * n - 1;

                    int t = Math.abs(tmpI - i) + Math.abs(tmpJ - j);
                    manhattan += t;

                }


            }
        }

    }

    // string representation of this board
    public String toString() {
        String str = Integer.toString(n);
        for (int i = 0; i < n; i++) {
            str = str + "\n";
            for (int j = 0; j < n; j++) {
                if (j == 0) {
                    str = str + tiles[i][j];
                }
                else
                    str = str + " " + tiles[i][j];
            }
        }
        return str;
    }


    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {

        return hamming;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {

        return manhattan;

    }

    // is this board the goal board?
    public boolean isGoal() {

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {

                int index = i * n + j + 1;
                if ((i == n - 1) && (j == n - 1)) {
                    if (tiles[i][j] != 0) {
                        return false;
                    }
                }
                else {
                    if (index != tiles[i][j]) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    // does this board equal y?
    public boolean equals(Object other) {

        if (other == this) return true;
        if (other == null) return false;
        if (other.getClass() != this.getClass()) return false;
        Board that = (Board) other;
        if (that.dimension() != n) return false;
        if (that.hamming() != hamming) return false;

        for (int i = 0; i < n; i++) {

            for (int j = 0; j < n; j++) {
                if (that.tiles[i][j] != tiles[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        Queue<Board> neighbors = new Queue<Board>();

        if (n <= 1) {
            return neighbors;
        }

        if (blankCol < 0 || blankRow < 0) {
            return neighbors;
        }

        // 上,左，右，下
        int[] dir = { -1, 0, 0, 1 };
        int[] hor = { 0, -1, 1, 0 };
        for (int i = 0; i < 4; i++) {

            boolean ret = isPosLegal(blankRow + dir[i], blankCol + hor[i]);
            if (ret) {
                Board board = new Board(tiles);
                board = exch(board, blankRow, blankCol, blankRow + dir[i], blankCol + hor[i]);
                neighbors.enqueue(board);
            }
        }

        return neighbors;
    }

    private boolean isPosLegal(int i, int j) {
        if (i < 0 || j < 0) {
            return false;
        }


        if (i >= n) {
            return false;
        }
        if (j >= n) {
            return false;
        }
        return true;
    }


    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        if (n == 1 || n == 0) {
            return null;
        }
        Board b = new Board(tiles);
        if (tiles[0][0] != 0 && tiles[0][1] != 0) {
            exch(b, 0, 0, 0, 1);
        }
        else {
            exch(b, n - 1, n - 1, n - 1, n - 2);
        }
        return b;
    }

    private Board exch(Board b, int i, int j, int k, int m) { // exchange two elements in the array

        int temp = b.tiles[i][j];
        b.tiles[i][j] = b.tiles[k][m];
        b.tiles[k][m] = temp;
        return b;
    }

    // unit testing (not graded)
    public static void main(String[] args) {

        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();

        // int[][] tiles;
        // tiles = new int[][] {
        //         // { 1, 0 },
        //         // { 3, 2 },
        //         { 1, 2, 3, },
        //         { 7, 6, 5, },
        //         { 7, 8, 0, },
        //         };
        Board t = new Board(tiles);
        StdOut.print(t.toString());

        StdOut.print(" \nhamming is :" + t.hamming());
        //
        StdOut.print(" \nmanhattan is : " + t.manhattan());
        //
        StdOut.print(" \ntwin is : " + t.twin().toString());

        Iterable<Board> a = t.neighbors();

        for (Board temp : a) {
            StdOut.print(" \n neighbors is : " + temp.toString());
        }

    }

    // public static void Test() {
    //     int[][] t1;
    //     t1 = new int[][] {
    //             { 8, 1, 3 },
    //             { 4, 0, 2 },
    //             { 7, 6, 5, },
    //             };
    //
    //     Board t = new Board(t1);
    //     StdOut.print(" que size  " + t.toString());
    //
    //     StdOut.print(" \nhamming is :" + t.hamming());
    //
    //     StdOut.print(" \nmanhattan is : " + t.manhattan());
    //
    //     StdOut.print(" \ntwin is : " + t.twin().toString());
    //
    //     Iterable<Board> a = t.neighbors();
    //
    //     for (Board temp : a) {
    //         StdOut.print(" \n neighbors is : " + temp.toString());
    //     }
    // }

}
